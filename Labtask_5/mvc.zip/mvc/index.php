<?php

// Include the controller file
include_once("controller/Controller.php");

// Create a new instance of the Controller
$controller = new Controller();

// Call the invoke method to start the application logic
$controller->invoke();

?>